package main

import (
        "github.com/gorilla/mux"

        "net/http"

	"log"
)

func main() {
	r := mux.NewRouter()
	r.HandleFunc("/webhook", VerificationEndPoint).Methods("GET")
	r.HandleFunc("/webhook", MessagesEndPoint).Methods("POST")

	// log.Fatal(http.ListenAndServe(":8080", r))
//	http.ListenAndServe(":80", r)


        err := http.ListenAndServeTLS(":8443", "/etc/letsencrypt/live/talktothebot.greatwwwhost.com/fullchain.pem", "/etc/letsencrypt/live/talktothebot.greatwwwhost.com/privkey.pem", r)
        if err != nil {
                log.Fatal("ListenAndServe: ", err)
        }

// http.ListenAndServeTLS(":443", "/etc/letsencrypt/live/www.yourdomain.com/fullchain.pem", "/etc/letsencrypt/live/www.yourdomain.com/privkey.pem", nil) 

/*
// https://stackoverflow.com/questions/37321760/how-to-set-up-lets-encrypt-for-a-go-server-application
    certManager := autocert.Manager{
        Prompt:     autocert.AcceptTOS,
        HostPolicy: autocert.HostWhitelist("talktothebot.greatwwwhost.com"), //your domain here
        Cache:      autocert.DirCache("certs"), //folder for storing certificates
    }


   server := &http.Server{
        Addr: ":443",
        TLSConfig: &tls.Config{
            GetCertificate: certManager.GetCertificate,
        },
    }

    log.Fatal(server.ListenAndServeTLS("", "")) // key and cert are comming from Let's Encrypt
*/
}
