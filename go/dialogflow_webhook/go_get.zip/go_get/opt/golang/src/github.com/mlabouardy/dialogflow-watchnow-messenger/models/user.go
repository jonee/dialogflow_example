package models

type User struct {
	ID string `json:"id,omitempty"`
}
